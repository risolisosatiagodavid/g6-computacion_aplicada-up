#!/bin/bash
# Script de Backup Automatizado - TP Computacion Aplicada

mostrar_ayuda() {
    echo "Uso: $0 [ORIGEN] [DESTINO]"
    echo "Ejemplo: $0 /var/log /backup_dir"
    echo ""
    echo "Parametros:"
    echo "  ORIGEN    Directorio a respaldar (ej: /var/log, /www_dir)"
    echo "  DESTINO   Directorio donde se guardara el backup (ej: /backup_dir)"
    echo "  -help     Muestra esta ayuda"
    exit 0
}

# Validacion de opcion de ayuda
if [ "$1" == "-help" ] || [ "$1" == "--help" ] || [ "$1" == "-h" ]; then
    mostrar_ayuda
fi

# Validacion de cantidad de argumentos
if [ $# -ne 2 ]; then
    echo "Error: Se requieren 2 argumentos (origen y destino)."
    mostrar_ayuda
fi

ORIGEN="$1"
DESTINO="$2"

# 1. Validar existencia de directorios
if [ ! -d "$ORIGEN" ]; then
    echo "Error: El directorio de origen '$ORIGEN' no existe."
    exit 1
fi

if [ ! -d "$DESTINO" ]; then
    echo "Error: El directorio de destino '$DESTINO' no existe."
    exit 1
fi

# 2. Validar disponibilidad de los sistemas de archivos (origen y destino)
if ! df "$ORIGEN" > /dev/null 2>&1; then
    echo "Error: El sistema de archivos de origen no esta disponible."
    exit 1
fi

if ! df "$DESTINO" > /dev/null 2>&1; then
    echo "Error: El sistema de archivos de destino no esta disponible."
    exit 1
fi

# 3. Validar permisos de escritura en destino
if [ ! -w "$DESTINO" ]; then
    echo "Error: No hay permisos de escritura en '$DESTINO'."
    exit 1
fi

# 4. Determinar nombre del archivo con formato ANSI 
BASE_NAME=$(basename "$ORIGEN")
FECHA_ANSI=$(date +"%Y%m%d")
NOMBRE_ARCHIVO="${BASE_NAME}_bkp_${FECHA_ANSI}.tar.gz"
RUTA_FINAL="${DESTINO}/${NOMBRE_ARCHIVO}"

echo "Iniciando backup de '$ORIGEN' hacia '$RUTA_FINAL'..."

# 5. Ejecutar la compresion
PARENT_DIR=$(dirname "$ORIGEN")
tar -czf "$RUTA_FINAL" -C "$PARENT_DIR" "$BASE_NAME"

if [ $? -eq 0 ]; then
    echo "Backup completado exitosamente: $RUTA_FINAL"
    exit 0
else
    echo "Error durante la creacion del backup."
    exit 1
fi
